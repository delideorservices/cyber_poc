<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserSkill;
use App\Models\UserCertification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class UserProfileController extends Controller
{
    public function show(Request $request)
    {
        $user = $request->user();
        
        // Load relationships
        $user->load(['sector', 'role', 'skills', 'certifications']);
        
        return response()->json($user);
    }
    
    public function update(Request $request)
    {
        $user = $request->user();
        
        $validator = Validator::make($request->all(), [
            'name' => 'sometimes|string|max:255',
            'email' => [
                'sometimes',
                'email',
                Rule::unique('users')->ignore($user->id),
            ],
            'gender' => 'sometimes|in:male,female,other,prefer_not_to_say',
            'age' => 'sometimes|integer|min:18|max:100',
            'sector_id' => 'sometimes|exists:sectors,id',
            'role_id' => 'sometimes|exists:roles,id',
            'years_experience' => 'sometimes|integer|min:0|max:50',
            'learning_goal' => 'sometimes|string|max:255',
            'preferred_language' => 'sometimes|string|max:10',
            'skills' => 'sometimes|array',
            'skills.*.id' => 'required|exists:skills,id',
            'skills.*.proficiency_level' => 'required|integer|min:1|max:5',
            'certifications' => 'sometimes|array',
            'certifications.*.id' => 'required|exists:certifications,id',
            'certifications.*.obtained_date' => 'nullable|date',
            'certifications.*.expiry_date' => 'nullable|date|after:obtained_date',
        ]);
        
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }
        
        // Update user profile
        $user->fill($validator->validated());
        $user->save();
        
        // Update skills if provided
        if ($request->has('skills')) {
            // Clear existing skills
            $user->skills()->detach();
            
            // Add new skills
            foreach ($request->skills as $skill) {
                $user->skills()->attach($skill['id'], [
                    'proficiency_level' => $skill['proficiency_level']
                ]);
            }
        }
        
        // Update certifications if provided
        if ($request->has('certifications')) {
            // Clear existing certifications
            $user->certifications()->detach();
            
            // Add new certifications
            foreach ($request->certifications as $cert) {
                $user->certifications()->attach($cert['id'], [
                    'obtained_date' => $cert['obtained_date'] ?? null,
                    'expiry_date' => $cert['expiry_date'] ?? null
                ]);
            }
        }
        
        // Reload relationships
        $user->load(['sector', 'role', 'skills', 'certifications']);
        
        return response()->json($user);
    }
}