import axios from 'axios';

const state = {
  user: null,
  token: localStorage.getItem('token') || null
};

const getters = {
  isAuthenticated: state => !!state.token,
  user: state => state.user
};

const actions = {
  async login({ commit }, credentials) {
    try {
      const response = await axios.post('/api/login', credentials);
      
      const token = response.data.token;
      localStorage.setItem('token', token);
      
      commit('SET_TOKEN', token);
      await dispatch('fetchUser');
      
      return response;
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  },
  
  async register({ commit, dispatch }, userData) {
    try {
      const response = await axios.post('/api/register', userData);
      
      const token = response.data.token;
      localStorage.setItem('token', token);
      
      commit('SET_TOKEN', token);
      await dispatch('fetchUser');
      
      return response;
    } catch (error) {
      console.error('Register error:', error);
      throw error;
    }
  },
  
  async fetchUser({ commit, state }) {
    try {
      if (!state.token) return;
      
      const response = await axios.get('/api/profile', {
        headers: {
          'Authorization': `Bearer ${state.token}`
        }
      });
      
      commit('SET_USER', response.data);
      return response;
    } catch (error) {
      console.error('Fetch user error:', error);
      commit('CLEAR_AUTH');
      throw error;
    }
  },
  
  async updateProfile({ commit, state }, profileData) {
    try {
      const response = await axios.put('/api/profile', profileData, {
        headers: {
          'Authorization': `Bearer ${state.token}`
        }
      });
      
      commit('SET_USER', response.data);
      return response;
    } catch (error) {
      console.error('Update profile error:', error);
      throw error;
    }
  },
  
  logout({ commit }) {
    commit('CLEAR_AUTH');
    localStorage.removeItem('token');
  }
};

const mutations = {
  SET_TOKEN(state, token) {
    state.token = token;
  },
  
  SET_USER(state, user) {
    state.user = user;
  },
  
  CLEAR_AUTH(state) {
    state.token = null;
    state.user = null;
  }
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
};