from fastapi import APIRouter, Body, HTTPException, Depends
from pydantic import BaseModel
from typing import Dict, Any, List, Optional
from app.agents.registration_agent import RegistrationAgent
from app.agents.profile_analyzer_agent import ProfileAnalyzerAgent
from app.agents.topic_mapper_agent import TopicMapperAgent
from app.agents.quiz_generator_agent import QuizGeneratorAgent
from app.agents.quiz_formatter_agent import QuizFormatterAgent
from app.agents.quiz_delivery_agent import QuizDeliveryAgent
from app.agents.evaluation_agent import EvaluationAgent
from app.agents.analytics_agent import AnalyticsAgent
from app.agents.feedback_agent import FeedbackAgent

router = APIRouter()

# Initialize agents
registration_agent = RegistrationAgent()
profile_analyzer_agent = ProfileAnalyzerAgent()
topic_mapper_agent = TopicMapperAgent()
quiz_generator_agent = QuizGeneratorAgent()
quiz_formatter_agent = QuizFormatterAgent()
quiz_delivery_agent = QuizDeliveryAgent()
evaluation_agent = EvaluationAgent()
analytics_agent = AnalyticsAgent()
feedback_agent = FeedbackAgent()

# Models for requests
class RegistrationRequest(BaseModel):
    name: str
    email: str
    password: Optional[str] = None
    gender: Optional[str] = None
    age: Optional[int] = None
    sector_id: int
    role_id: int
    years_experience: Optional[int] = None
    learning_goal: Optional[str] = None
    preferred_language: Optional[str] = "en"
    topic_id: int
    skills: Optional[List[Dict[str, Any]]] = []
    certifications: Optional[List[Dict[str, Any]]] = []

class QuizResponseRequest(BaseModel):
    user_id: int
    quiz_id: int
    responses: List[Dict[str, Any]]

# Routes for agent interaction
@router.post("/register")
async def register_user(request: RegistrationRequest):
    """Register a new user and start quiz generation process"""
    try:
        # Run registration agent
        result = registration_agent.run(request.dict())
        
        # Continue the agent chain
        if result.get('next_agent') == 'profile_analyzer':
            profile_result = profile_analyzer_agent.run(result)
            
            if profile_result.get('next_agent') == 'topic_mapper':
                topic_result = topic_mapper_agent.run(profile_result)
                
                if topic_result.get('next_agent') == 'quiz_generator':
                    quiz_result = quiz_generator_agent.run(topic_result)
                    
                    if quiz_result.get('next_agent') == 'quiz_formatter':
                        format_result = quiz_formatter_agent.run(quiz_result)
                        
                        if format_result.get('next_agent') == 'quiz_delivery':
                            delivery_result = quiz_delivery_agent.run(format_result)
                            return delivery_result
                        
                        return format_result
                    
                    return quiz_result
                
                return topic_result
            
            return profile_result
        
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/evaluate")
async def evaluate_quiz(request: QuizResponseRequest):
    """Process user quiz responses and provide feedback"""
    try:
        # Run evaluation agent
        result = evaluation_agent.run(request.dict())
        
        # Continue the agent chain
        if result.get('next_agent') == 'analytics':
            analytics_result = analytics_agent.run(result)
            
            if analytics_result.get('next_agent') == 'feedback':
                feedback_result = feedback_agent.run(analytics_result)
                return feedback_result
            
            return analytics_result
        
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/run-agent/{agent_name}")
async def run_single_agent(agent_name: str, data: Dict[str, Any] = Body(...)):
    """Run a specific agent with provided data"""
    try:
        agent = None
        
        if agent_name == "registration":
            agent = registration_agent
        elif agent_name == "profile_analyzer":
            agent = profile_analyzer_agent
        elif agent_name == "topic_mapper":
            agent = topic_mapper_agent
        elif agent_name == "quiz_generator":
            agent = quiz_generator_agent
        elif agent_name == "quiz_formatter":
            agent = quiz_formatter_agent
        elif agent_name == "quiz_delivery":
            agent = quiz_delivery_agent
        elif agent_name == "evaluation":
            agent = evaluation_agent
        elif agent_name == "analytics":
            agent = analytics_agent
        elif agent_name == "feedback":
            agent = feedback_agent
        else:
            raise HTTPException(status_code=404, detail=f"Agent '{agent_name}' not found")
        
        result = agent.run(data)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))