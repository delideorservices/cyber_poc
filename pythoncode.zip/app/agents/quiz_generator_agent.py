import json
from typing import Dict, Any, List
from app.agents.base_agent import BaseAgent
from app.services.db_service import db_service
from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from app.config import OPENAI_API_KEY

class QuizGeneratorAgent(BaseAgent):
    """Agent for generating personalized quiz content"""
    
    def __init__(self):
        super().__init__(
            name="QuizGeneratorAgent",
            description="Generates personalized quiz content based on topic and user profile"
        )
        
        # Initialize LLM
        self.llm = OpenAI(
            temperature=0.7,
            openai_api_key=OPENAI_API_KEY
        )
    
    def _execute(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a personalized quiz based on topic and user profile
        
        Args:
            inputs: Dictionary containing topic and profile data
            
        Returns:
            Dictionary with generated quiz data
        """
        # Validate required inputs
        self._validate_inputs(inputs, ['user_id', 'topic_id', 'topic_name', 'experience_level'])
        
        # Extract key parameters
        user_id = inputs['user_id']
        topic_id = inputs['topic_id']
        topic_name = inputs['topic_name']
        experience_level = inputs['experience_level']
        topic_description = inputs.get('topic_description', '')
        user_role = inputs.get('user_role', 'Employee')
        user_sector = inputs.get('user_sector', 'General')
        focus_areas = inputs.get('focus_areas', ['General Cybersecurity'])
        
        # Create quiz title
        quiz_title = f"{topic_name} - Cybersecurity Quiz"
        
        # Insert quiz record
        quiz_id = db_service.execute_returning(
            """
            INSERT INTO quizzes
            (title, description, user_id, topic_id, difficulty_level, created_at, updated_at)
            VALUES (%s, %s, %s, %s, %s, NOW(), NOW())
            RETURNING id
            """,
            (
                quiz_title,
                f"Personalized quiz about {topic_name} with focus on {user_sector} sector and {user_role} role",
                user_id,
                topic_id,
                experience_level
            )
        )
        
        # Generate quiz chapters and questions
        quiz_content = self._generate_quiz_content(
            topic_name=topic_name,
            topic_description=topic_description,
            experience_level=experience_level,
            user_role=user_role,
            user_sector=user_sector,
            focus_areas=focus_areas
        )
        
        # Insert quiz chapters and questions
        self._save_quiz_content(quiz_id, quiz_content)
        
        # Return generated quiz data
        return {
            'user_id': user_id,
            'quiz_id': quiz_id,
            'quiz_title': quiz_title,
            'quiz_content': quiz_content,
            'status': 'success',
            'next_agent': 'quiz_formatter'
        }
    
    def _generate_quiz_content(self, topic_name: str, topic_description: str, 
                               experience_level: int, user_role: str, 
                               user_sector: str, focus_areas: List[str]) -> Dict:
        """
        Generate quiz content using LangChain
        
        Args:
            topic_name: Main topic name
            topic_description: Topic description
            experience_level: User experience level (1-5)
            user_role: User's role
            user_sector: User's sector
            focus_areas: Focus areas for the quiz
            
        Returns:
            Dictionary with generated quiz chapters and questions
        """
        # Create prompt template
        prompt = PromptTemplate(
            template="""
            Create a cybersecurity quiz on the topic of "{topic_name}"{topic_desc_text}.
            
            The quiz should be tailored for someone who:
            - Works in the {user_sector} sector
            - Has the role of {user_role}
            - Has an experience level of {experience_level} out of 5
            
            Focus areas should include: {focus_areas}
            
            Create 4 chapters:
            1. Cybersecurity Basics related to {topic_name}
            2. {user_role}-specific Risks
            3. {user_sector}-specific Threats
            4. Advanced Challenges
            
            For each chapter, create 5 questions with a mix of:
            - Multiple choice (3-4 options, 1 correct)
            - True/False
            - Fill in the blank
            
            Format your response as a valid JSON object with this structure:
            {{
                "chapters": [
                    {{
                        "title": "Chapter title",
                        "description": "Brief chapter description",
                        "questions": [
                            {{
                                "type": "mcq" | "true_false" | "fill_blank",
                                "content": "Question text",
                                "options": ["Option 1", "Option 2", "Option 3", "Option 4"],
                                "correct_answer": "Correct answer text or index (0-based for MCQ)",
                                "explanation": "Explanation of why this is the correct answer"
                            }}
                        ]
                    }}
                ]
            }}
            
            Ensure that:
            - Questions are practical and relevant to real-world scenarios
            - Difficulty matches the experience level ({experience_level}/5)
            - Questions focus on cybersecurity best practices
            - All JSON is properly formatted and valid
            """,
            input_variables=["topic_name", "topic_desc_text", "experience_level", "user_role", "user_sector", "focus_areas"]
        )
        
        # Format topic description if available
        topic_desc_text = f" ({topic_description})" if topic_description else ""
        
        # Format focus areas as comma-separated string
        focus_areas_str = ", ".join(focus_areas)
        
        # Run LLM chain
        chain = LLMChain(llm=self.llm, prompt=prompt)
        result = chain.run(
            topic_name=topic_name,
            topic_desc_text=topic_desc_text,
            experience_level=experience_level,
            user_role=user_role,
            user_sector=user_sector,
            focus_areas=focus_areas_str
        )
        
        # Parse JSON result
        try:
            # Find JSON content - handle case where LLM might add explanatory text
            json_start = result.find('{')
            json_end = result.rfind('}') + 1
            json_content = result[json_start:json_end]
            
            quiz_data = json.loads(json_content)
            return quiz_data
        except Exception as e:
            # Log error and generate fallback content
            db_service.log_agent_action(
                agent_name=self.name,
                action="parse_quiz_json",
                input_data={"result": result},
                status="error",
                error_message=str(e)
            )
            
            # Return fallback content
            return self._generate_fallback_quiz(topic_name, user_role, user_sector)
    
    def _save_quiz_content(self, quiz_id: int, quiz_content: Dict) -> None:
        """
        Save generated quiz content to the database
        
        Args:
            quiz_id: ID of the quiz
            quiz_content: Generated quiz content
        """
        chapters = quiz_content.get('chapters', [])
        
        for chapter_idx, chapter in enumerate(chapters):
            # Insert chapter
            chapter_id = db_service.execute_returning(
                """
                INSERT INTO chapters
                (quiz_id, title, description, sequence, created_at, updated_at)
                VALUES (%s, %s, %s, %s, NOW(), NOW())
                RETURNING id
                """,
                (
                    quiz_id,
                    chapter.get('title', f"Chapter {chapter_idx + 1}"),
                    chapter.get('description', ''),
                    chapter_idx + 1
                )
            )
            
            # Insert questions
            questions = chapter.get('questions', [])
            for question_idx, question in enumerate(questions):
                # Ensure options is a list
                options = question.get('options', [])
                if question.get('type') == 'true_false':
                    options = ['True', 'False']
                
                # Format correct answer based on question type
                correct_answer = question.get('correct_answer')
                if isinstance(correct_answer, int) or (isinstance(correct_answer, str) and correct_answer.isdigit()):
                    # Handle index-based answer (convert to string for consistency)
                    correct_answer = str(correct_answer)
                
                db_service.execute(
                    """
                    INSERT INTO questions
                    (chapter_id, type, content, options, correct_answer, explanation, sequence, points, created_at, updated_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, NOW(), NOW())
                    """,
                    (
                        chapter_id,
                        question.get('type', 'mcq'),
                        question.get('content', ''),
                        json.dumps(options),
                        json.dumps(correct_answer),
                        question.get('explanation', ''),
                        question_idx + 1,
                        1  # Default point value
                    )
                )
    
    def _generate_fallback_quiz(self, topic_name: str, user_role: str, user_sector: str) -> Dict:
        """
        Generate a fallback quiz in case of LLM failure
        
        Args:
            topic_name: Main topic name
            user_role: User's role
            user_sector: User's sector
            
        Returns:
            Dictionary with fallback quiz structure
        """
        return {
            "chapters": [
                {
                    "title": "Cybersecurity Basics",
                    "description": f"Fundamental concepts related to {topic_name}",
                    "questions": [
                        {
                            "type": "mcq",
                            "content": f"Which of the following is a common {topic_name} threat?",
                            "options": ["Phishing attacks", "Social engineering", "Malware", "All of the above"],
                            "correct_answer": "3",
                            "explanation": "All of these are common cybersecurity threats."
                        },
                        {
                            "type": "true_false",
                            "content": "Strong passwords must be changed every 90 days.",
                            "options": ["True", "False"],
                            "correct_answer": "False",
                            "explanation": "Current NIST guidelines suggest changing passwords only when compromised."
                        }
                    ]
                },
                {
                    "title": f"{user_role} Specific Risks",
                    "description": f"Security risks specific to {user_role} roles",
                    "questions": [
                        {
                            "type": "mcq",
                            "content": f"As a {user_role}, what is your primary security responsibility?",
                            "options": ["Following security policies", "Reporting incidents", "Protecting customer data", "All of the above"],
                            "correct_answer": "3",
                            "explanation": "All of these are important security responsibilities."
                        }
                    ]
                },
                {
                    "title": f"{user_sector} Specific Threats",
                    "description": f"Threats specific to the {user_sector} sector",
                    "questions": [
                        {
                            "type": "fill_blank",
                            "content": f"The most common type of attack in the {user_sector} sector is ______.",
                            "correct_answer": "data breach",
                            "explanation": "Data breaches are particularly common in this sector."
                        }
                    ]
                }
            ]
        }